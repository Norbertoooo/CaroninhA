public class Motorista {
    String nome;
    int idade;
    String cpf;
    String destino;
    String senha;

}
