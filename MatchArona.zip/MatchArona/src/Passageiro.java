public class Passageiro {
    public String nome;
    public int idade;
    public String cpf;
    public String destino;
    private String senha;

}
