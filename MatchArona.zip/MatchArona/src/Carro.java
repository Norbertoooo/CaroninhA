public class Carro {
    String modelo;
    String chassi;
    String marca;
    int ano;
    String placa;
    String cor;
}
