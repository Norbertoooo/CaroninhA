public class Trajeto {
}
