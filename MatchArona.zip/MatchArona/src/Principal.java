import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        System.out.println("**********************************************");
        System.out.println("\t\t\t\tMATCH-ARONA");
        System.out.println("**********************************************");
        System.out.println();
        System.out.println("**********************************************");
        String escolha;
        ArrayList listap = new ArrayList();
        Passageiro passageiro = new Passageiro();
        Iterator i = listap.iterator();

        Motorista motorista = new Motorista();
        do{
            System.out.println("\t\t\t\t\tMENU");
            System.out.println("**********************************************");
            System.out.println("Digite a opiçao");
            Scanner scan = new Scanner(System.in);
            escolha = scan.nextLine().toLowerCase();
            switch (escolha){
                case "cadastro":
                    System.out.println("Digite o nome: ");
                    passageiro.nome = scan.nextLine();
                    listap.add(passageiro);
                    System.out.println(passageiro.nome);
                    break;
            }

        }while(escolha.equals("cadastro") == true );

    }
}
